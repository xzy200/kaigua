for a in {1..10}
do
    clear
    python3 sleep.py | figlet | cowsay -f moose -n | lolcat
    sleep 1s
done
