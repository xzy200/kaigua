import time
print(time.strftime("%H:%M:%S"), end = "")
