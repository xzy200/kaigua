python3 sleep.py | figlet
python3 sleep.py | figlet
python3 sleep.py | figlet
