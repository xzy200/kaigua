'''if syntax
if expression:
    do this
'''
number = int(input("Enter a number: "))
if number < 100:
    print("The number is less than 100")
