name = input("Enter the file name: ")
fobj = open(name)
print(fobj.read())
fobj.close()
