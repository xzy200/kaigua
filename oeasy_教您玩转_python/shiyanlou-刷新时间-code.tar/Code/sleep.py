import time
i = 1
while True:
    print(time.asctime())
    i = i + 1
    time.sleep(1)
