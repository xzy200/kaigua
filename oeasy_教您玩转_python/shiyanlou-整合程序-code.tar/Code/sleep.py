import time
while True:
    print("localtime:" + time.asctime())
    time.sleep(1)
