# The while statement (yuju)
"""
while condition:
    statement1
    statement2
"""

# 打印斐波那契数列。这个数列前两项为 1 ，之后的每一项都是前两项之和。
# 将值 0 分配给变量 a；值 1 分配给变量 b。
a, b = 0, 1
# 当 b < 100 时，打印输出 b。
while b < 100:
    print(b)
    # 将值 a + b 分配给变量 b；将值 b 分配给变量 a。
    b, a = a + b, b
