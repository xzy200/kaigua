# 这里是一些你可以在大学的实验报告里经常看到的例子。

"""
# design1
# 将读取输入为 int （integer （整数）） 的值分配给变量 row。
row = int(input("Please enter an integer of rows: "))
# 将 row 的值分配给变量 n。
n = row
# 当 n >= 0 时，将字符串 "*" * n 的值分配给变量 x。
while n >= 0:
    x = "*" * n
    # 打印输出 x。
    print(x)
    # 简化表达式 n = n - 1。
    n -= 1
"""

"""
# design2
# 将读取输入为整数 int 的值跟·分配给变量 n。
n = int(input("Please enter an integer of rows: "))
# 将 1 的值分配给变量 i。
i = 1
# 当 i <= n 时，打印输出 "*" * i。
while i <= n:
    print("*" * i)
    # 简化表达式 i = i + 1。
    i += 1
"""

# design3
# 将读取输入为整数 int 的值分配给变量 row。
row = int(input("Please enter an integer of rows: "))
# 将 row 的值分配给变量 n。
n = row
# 当 n >= 0 时，执行
while n >= 0:
    # 将 "*" * n 的值分配给变量 x。
    x = "*" * n
    # 将 " " * (row - n) 的值分配给变量 y。
    y = " " * (row - n)
    # 打印输出 y + x。
    print(y + x)
    # 简化表达式 n = n - 1。
    n -= 1
