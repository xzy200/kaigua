# 用 print() 另外一个参数 end，替换 print() 默认打印的一个换行符。
# 将值 0 分配给变量 a；将值 1 分配给变量 b。
a, b = 0, 1
# 当 b < 100 时，打印输出 b ，并用 end 替换换行符。
while b < 100:
    print(b, end = " ")
    # 将值 a + b 分配给变量 b；将值 b 分配给变量 a。
    b, a = a + b, b
