"""
规则：这里有 21 根棍子，
首先用户选 1 到 4 根棍子，然后电脑选 1 到 4 根棍子。（用户 + 电脑 = 5 / 次）
谁选到最后一根棍子谁就输。

要求：修改规则让用户有赢得机会。
sticks = 21

print("There are 21 sticks, you can take 1-4 number of sticks at a time.")
print("Whoever will take the last stick will lose")

while True:
    print("Sticks left: " , sticks)
    if sticks == 1:
        print("You took the last stick, you lose")
        break
    sticks_taken = int(input("Take sticks(1-4):"))
    if sticks_taken >= 5 or sticks_taken <= 0:
        print("Wrong choice")
        continue
    print("Computer took: " , (5 - sticks_taken) , "\n")
    sticks -= 5
"""

# 修改：只需将棍子的总数修改为 5 的倍数，则电脑无论如何都会拿到最后的一根(一些小修改详见第38行)
sticks = 20

print("There are 21 sticks, you can take 1-4 number of sticks in a time.")
print("Whoever will take the last stick will lose.")

# 当为 True 时，打印输出 "Sticks left: ", sticks
while True:
    print("Sticks left: ", sticks)
    # 如果 sticks == 1 时，打印输出 "You took the last stick, you lose." 并打破当前 while 循环。
    if sticks == 1:
        print("You took the last stick, you lose.")
        break
    # 如果 sticks == 0 ，打印输出 "Computer took the last stick, you win." 并打破当前 while 循环。
    if sticks == 0:
        print("Computer took the last stick, you win.")
        break
    # 将读取输入为 int 的值分配给变量 sticks_taken。
    sticks_taken = int(input("Please enter 1-4 numbers of sticks: "))
    # 如果 sticks_taken <= 0 or sticks_taken >= 5 ，则打印输出 "Wrong choice" ，并继续 while 循环的下一次迭代。
    if sticks_taken <=0 or sticks_taken >= 5:
        print("Wrong choice")
        continue
    # 打印输出 "Computer took: ", 5 - sticks_taken
    print("Computer took: ", 5 - sticks_taken)
    # 简化表达式 sticks = sticks - 5
    sticks -= 5
