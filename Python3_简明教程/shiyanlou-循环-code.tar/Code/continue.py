"""
此程序要求用户输入一个整数,
如果输入负数，则要求再次输入；
如果输入整数，则计算这个数的平方；
如果输入 0 ，则跳出这个无限循环。
"""

# 当为 Ture 时，将读取输入为整数的值分配给变量 n。
while True:
    n = int(input("Please enter an integer: "))
    # 如果 n < 0 时，继续 while 循环的下一次迭代。
    if n < 0:
        continue
    # 否则，如果 n == 0 时，打破当前 while 循环。
    elif n == 0:
        break
    # 否则，打印输出字符串 "Square is "，表达式 n ** 2。
    else:
        print("Square is ", n ** 2)
# 打印输出字符串 "Goodbye"
print("Goodbye")
