# 计算幂级数 e^x = 1 + x + x^2 / 2! + x^3 / 3! + ... + X^n / n! (0 < x < 1)。
# 读取输入为 float （浮点数）的值，分配给变量 x。
x = float(input("Please enter a value of x: "))
# 将值 1 分配给变量 term ，将 term 的值分配给变量 n。
n = term = 1
# 将 1.0 的值分配给变量 result。
result = 1.0
# 当 n <= 100 时，执行表达式 term = term * x / n 、表达式 result = result + term 以及表达式 n = n + 1。
while n <= 100:
# 简化表达式 term = term * x / n。
    term *= x / n
    # 简化表达式 result = result + term。
    result += term
    # 简化表达式 n = n + 1。
    n += 1
    # 如果 term < 0.0001 执行 break （打破当前 while 循环）
    if term < 0.0001:
        break
# 打印输出字符串 "No of Times = n and sum = result" 并格式化 n 和 result。
print("No of Times = {} and sum = {}".format(n, result))
