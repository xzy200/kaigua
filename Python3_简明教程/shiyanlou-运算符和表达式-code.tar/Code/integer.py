# v1.0.0
# days = int(input("Please enter days: "))
# months = days // 30
# days %= 30
# print("Months = {} Days = {}".format(months, days))

# v1.0.1
# 把读取输入作为整数的值，分配给变量 days。
days = int(input("Please enter days: "))
# "divmod(num1, num2)": 返回一个元组 （1. num1 // num2 (整) 2. num1 % num2 (余)）; "*": 拆分这个元组
print("Months = {} Days = {}".format(*divmod(days, 30)))
