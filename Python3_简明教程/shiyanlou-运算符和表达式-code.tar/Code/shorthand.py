N = 100
a = 2
# 当 a < N 时，打印输出作为字符串的变量 a。
while a < N:
    print(str(a))
    # 简写 a = a * a。
    a *= a
