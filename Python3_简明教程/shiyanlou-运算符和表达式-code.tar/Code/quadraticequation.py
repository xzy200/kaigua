# 导入 math function。
import math
# 分别读取输入为整数。
a = int(input("Please enter value of a: "))
b = int(input("Please enter value of b: "))
c = int(input("Please enter value of c: "))
# 将 b ** 2 - 4 * a * c 的值分配给变量 d。
d = b ** 2 - 4 * a * c
# 如果 d < 0 则打印输出 "ROOTS are imaginary"。
if d < 0:
    print("ROOTS are imaginary")
# 否则，将 (-b + math.sqrt(d)) / (2 * a) 的值分配给变量 root1,
# 将 (-b - math.sqrt(d)) / (2 * a) 的值分配给变量 root2
# sqrt 是 square root （平方根）。
else:
    root1 = (-b + math.sqrt(d)) / (2 * a)
    root2 = (-b - math.sqrt(d)) / (2 * a)
    # 打印输出字符串 "Root 1 = " 变量 root1。
    # 打印输出字符串 "Root 2 = " 变量 root2。
    print("Root 1 = ", root1)
    print("Root 2 = ", root2)
