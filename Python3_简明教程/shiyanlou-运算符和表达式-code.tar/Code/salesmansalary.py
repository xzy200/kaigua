# 这个程序计算一位数码相机销售人员的工资。
# 他的基本工资是 1500，每售出一台相机他可以得到 200 并且获得 2% 的抽成。
# 程序要求输入相机数量及单价。
basic_salary = 1500
bonus_rate = 200
commission_rate = 0.02
# 读取 "Please enter the number of inputs sold: " 输入为整数的值分配给变量 numberofcamera。
numberofcamera = int(input("Please enter the number of inputs sold: "))
# 读取 "Please enter the price of camera: " 输入为整数的值分配给变量 price。
price = int(input("Please enter the price of camera: "))
# 将 bonus_rate * numberofcamera 的值分配给变量 bonus。
bonus = bonus_rate * numberofcamera
# 将 commission_rate * price * numberofcamera 的值分配给变量 commission。
commission = commission_rate * price * numberofcamera
# 打印输出 Bonus = 格式化 bonus 六位字符宽度小数点后两位。
print("Bonus = {:6.2f}".format(bonus))
# 打印输出 Commission = 格式化 commission 六位字符宽度小数点后两位。
print("Commission = {:6.2f}".format(commission))
# 打印输出 Gross salary = 格式化 basic_salary + bonus + commission 六位字符宽度小数点后两位。
print("Gross salary = {:6.2f}".format(basic_salary + bonus + commission))
