# 直接打印输出半径为 2 的圆面积，保留小数点后 10 位。
# 导入 math 数学函数。
import math
# 把半径为 2 的圆面积公式的值分配给变量 circlearea (math.pi: mathematical constant (数学常数)== 3.1415...)
circlearea = math.pi * 2 * 2
# 格式化打印输出 criclearea 小数点后 10 位。
print("CircleArea = {:.10f}".format(circlearea))
