# 转化华氏温度为摄氏温度（公式：C = (F - 32) / 1.8）
fahrenheit = 0
# 当 fahrenheit <= 250 时，将 (fahrenheit - 32) / 1.8 的值分配给变量 celsius。
while fahrenheit <= 250:
    celsius = (fahrenheit - 32) / 1.8
    # 打印输出 fahrenheit, celsius 并分别格式化数字为 5 个字符宽度，格式化数字为 7 个字符宽度.四舍五入到小数点后两位。
    print("{:5} {:7.2f}".format(fahrenheit, celsius))
    fahrenheit += 25
