# 读取输入作为 float （浮点数），并将此浮点数分配给变量 （amount）（数量）。
amount = float(input("Please enter amount: "))
# 读取输入作为 float （浮点数），并将此浮点数分配给变量（interest_rate）（利率）
interest_rate = float(input("Please enter interest_rate: "))
# 读取输入作为 int (整数)，并将此整数分配给变量（period）(时期)
period = int(input("Please enter period: "))
year = 1
# 当 year <= period 时，执行从属代码，否则不再循环。
while year <= period:
    # 将 amount + (amount * interest_rate) 的值分配给变量 all_value。
    all_value = amount + (amount * interest_rate)
    # 格式化字符串 （用变量 year 和 all_value 代替） ，并保留 2 位小数，并打印输出 Year {} Rs. {}。
    print("Year {} Rs. {:.2f}".format(year, all_value))
    # 将值 all_value 分配给变量 amount。
    amount = all_value
    # 将 year + 1 分配给 year。
    year += 1

# 输出结果
"""
Please enter amount: 10000
Please enter interest_rate: 0.14
Please enter period: 5
Year 1 Rs. 11400.00
Year 2 Rs. 12996.00
Year 3 Rs. 14815.44
Year 4 Rs. 16889.60
Year 5 Rs. 19254.15
"""
