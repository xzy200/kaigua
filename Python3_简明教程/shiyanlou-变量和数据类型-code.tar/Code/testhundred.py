 读取输入作为整数，并将此整数分配给变量 number。
number = int(input("Please enter an integer: "))
"""
当 number <= 100，执行从属代码 prin("Your number is less than or equal to 100")，
否则，执行从属代码 print("Your number is greater than 100")
"""
if number <= 100:
    print("Your number is less than or equal to 100")
else:
    print("Your number is greater than 100")
