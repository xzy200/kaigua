# 输入 10 个数字，并计算 10 个数的平均值。
numbers = 0
total = 0
print("Please enter 10 numbers: ")
# 当 numbers <= 10 ，则实现每个数相加的功能
while numbers <= 10:
    numbers += 1
    # 把读取输入作为浮点数的值，分配给 number。
    number = float(input())
    # 把 tatal + number 的值，分配给 total。
    total += number
    # 如果 numbers == 10 ，则实现平均值的打印输出功能并 break （打破当前 while 循环）
    if numbers == 10:
        average = total / 10
        # 格式化变量 average 被分配的数字，并保留两位小数，接着打印输出它。
        print("average: {:.2f}".format(average))
        # 打破当前 while 循环。
        break
