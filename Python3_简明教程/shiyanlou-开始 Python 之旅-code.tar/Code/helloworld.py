#!/usr/bin/env python3
# use Python interpreter to execute print() method
print("Hello World!")
