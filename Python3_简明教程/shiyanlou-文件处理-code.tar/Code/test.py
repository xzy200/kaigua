#!/usr/bin/env python3
name = input("Enter the file neme: ")
fobj = open(name)
print(fobj.read())
fobj.close()
