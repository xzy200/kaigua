# # if statement (yuju)
# """
# if expression:
#     do this
# """
#
# # 把读取输入为整数的值分配给变量 number 。
# number = int(input("Please enter an integer: "))
# # 如果 number < 100，则打印输出 "The number is less than 100."
# if number < 100:
#     print("The number is less than 100.")

# 把读取输入为整数的值分配给变量 number。
number = int(input("Please enter an integer: "))
# 如果 number < 100，则打印输出 "The number is less than 100."
if number < 100:
    print("The number is less than 100.")
# 否则打印输出 "The number is greater than 100."
else:
    print("The number is greater than 100.")
