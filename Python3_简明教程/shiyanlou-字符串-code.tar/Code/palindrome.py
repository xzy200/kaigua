s = input("Please enter a string: ")
z = s[::-1]
if s == z:
    print("The string is a palindroma")
else:
    print("The string is not a palindroma")
