"""
这是一个判断学生成绩是否达标的程序,
要求输入学生数量，以及各个学生物理、数学、历史三科的成绩，
如果总成绩小于 120 ，程序打印 "failed" ，否则打印 "passed"。
"""

# 将读取输入为 int 的值，分配给变量 number_of_students。
number_of_students = int(input("Please enter a number of students: "))
#
