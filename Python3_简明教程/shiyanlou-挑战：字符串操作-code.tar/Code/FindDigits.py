# 打开并读取文件里的字符串
with open('/tmp/String.txt') as f: # /tmp/String.txt 是路径，你也可以改成 String.txt , 并将文件 String.txt 放在当前目录下
    s = f.read()
    res = ""
    # 循环字符串里的每个字符，判断是否为数字
    for i in s:
        if i.isdigit():
            res += i
    print(res)
