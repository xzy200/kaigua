# while syntax
'''
while condition:
    statement1
    statement1
'''
a, b = 0, 1
while b < 100:
    print(b)
    a, b = b, a + b
