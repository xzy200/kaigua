# 让用户输入一个整数，分配给变量 a.
a = int(input("Please enter a integer: "))
"""
如果 a > 10，则执行从属代码，否则跳过;
从属代码，请使用 4 个空格来缩进。
"""
if a > 10:
    print("a > 10")
# 如果 a == 10，则执行从属代码，否则跳过。
elif a == 10:
    print("a == 10")
# 如果上面条件都不满足，则执行从属代码。
else:
    print("a < 10")
